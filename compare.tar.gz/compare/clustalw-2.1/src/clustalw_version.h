#ifndef CLUSTALW_VERSION_H
#define CLUSTALW_VERSION_H

#define CLUSTALW_NAME "ClustalW"

#define CLUSTALW_VERSION "2.1"

#endif

